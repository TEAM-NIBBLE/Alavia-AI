# Alavia AI API

Laravel REST API for the Alavia AI voice-first health triage assistant.

## Goals
- API-only JSON responses
- Health check endpoint
- Placeholder for triage + routing logic

## Requirements
- PHP 8.2+
- Composer
- MySQL (or compatible)

## Setup
1. Copy `.env.example` to `.env` and fill required values.
2. Install dependencies: `composer install`
3. Generate app key: `php artisan key:generate`
4. Run migrations: `php artisan migrate`

## Environment Variables
Required:
- `APP_KEY`
- `DB_CONNECTION`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`
- `OPENAI_KEY`
- `ENCRYPTION_KEY`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## Database Schema
Tables:
- `users`
- `admin_users`
- `hospitals`
- `hospital_facilities`
- `hospital_specialties`
- `consultations`
- `consultation_messages`
- `audit_logs`

Notes:
- `hospital_facilities` and `hospital_specialties` allow `hospital_id` to be null so template rows can exist before hospitals are seeded.

## Health Check
- `GET /api/health`

## Auth (Sanctum)
Endpoints:
- `POST /api/auth/register`
- `POST /api/auth/login` (rate limited)
- `POST /api/auth/logout` (requires `auth:sanctum`)
- `POST /api/auth/forgot-password` (rate limited, returns reset token in response)
- `POST /api/auth/reset-password`

Notes:
- Passwords are hashed with bcrypt via Laravel's default hashing.
- Password reset tokens are stored in `password_reset_tokens`.

## User Profile
Endpoints (auth required):
- `GET /api/user/profile`
- `PATCH /api/user/profile`

Response:
- Uses `UserResource`.

## Hospital Sync (Overpass)
Environment:
- `OVERPASS_URL` (default: `https://overpass-api.de/api/interpreter`)
- `OVERPASS_LAGOS_BBOX` (default: `6.35,2.70,6.80,3.70`)

Command:
- `php artisan hospitals:sync-lagos`
- `php artisan hospitals:sync-lagos --limit=50`

Notes:
- Uses Overpass QL area query for Lagos State with a bbox fallback.
- Responses are cached for 24 hours in `storage/app/cache`.

## Hospitals API
Endpoints:
- `GET /api/hospitals`
- `GET /api/hospitals/{id}`

Query params:
- `lat`, `lng`
- `specialty`, `facility`
- `severity`
- `is_public`, `is_24_hours`, `emergency_ready`
- `min_rating`

Notes:
- Returns top 10 ranked hospitals by score.
- Response includes `distance_km` when `lat` and `lng` are provided.

## Consultations (Triage)
Endpoints (auth required):
- `POST /api/consultations/start`
- `POST /api/consultations/{id}/message`
- `GET /api/consultations/{id}`
- `GET /api/consultations/history`
- `DELETE /api/consultations/{id}`

Notes:
- Messages and summaries are stored encrypted (AES-256) using `ENCRYPTION_KEY`.
- Triage questions are rule-based and language-specific (EN, PIDGIN, YORUBA, HAUSA, IGBO).
- Severity is determined by rules/red flags (no AI severity decisions).
- Optional AI classifier can map transcripts to categories and red flags using `TRIAGE_AI_ENABLED=true`.

## Speech (OpenAI)
Endpoints:
- `POST /api/speech/stt` (multipart `audio`, optional `language`)
- `POST /api/speech/tts` (json `text`, `language`, `voice`)

Notes:
- Uses `OPENAI_API_KEY` (falls back to `OPENAI_KEY`).
- TTS audio files are stored in `storage/app/public/tts` and returned as public URLs.
- Run `php artisan storage:link` to serve audio from the public disk.

## Admin
Endpoints:
- `POST /api/admin/login`
- `GET/POST/PATCH/DELETE /api/admin/hospitals`
- `POST /api/admin/hospitals/{id}/specialties`
- `POST /api/admin/hospitals/{id}/facilities`
- `GET /api/admin/analytics/overview`

Notes:
- Admin endpoints require a Sanctum token from admin login.

## API Docs
- OpenAPI: `docs/openapi.yaml`
- Postman: `docs/postman_collection.json`

## Seeders
- `AdminUserSeeder`: creates a default `SUPERADMIN` from `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
- `HospitalMetaSeeder`: inserts template facilities and specialties (no hospitals yet).

## Notes
Business logic is intentionally not implemented yet.
